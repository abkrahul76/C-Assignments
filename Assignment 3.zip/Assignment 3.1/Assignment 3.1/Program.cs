﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 29 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int c;
            double r1;
            double r2;
            double r3;
            Console.WriteLine("Enter a:");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter b:");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter c:");
            c = Convert.ToInt32(Console.ReadLine());
            r3 = ((b * b) - 4 * a * c);
            if (r3 < 0)
                Console.WriteLine("The equation has no real roots");
            r1 = ((-b + Math.Sqrt(r3)) / 2 * a);
            r2 = ((b + Math.Sqrt(r3)) / 2 * a);
            if (r3 == 0)
                Console.WriteLine("The equation has one root :{0}", r1);
            if (r3 > 0)
                Console.WriteLine("The equation has two roots: {0} and {1}", r1,r2);
        }
    }
}
