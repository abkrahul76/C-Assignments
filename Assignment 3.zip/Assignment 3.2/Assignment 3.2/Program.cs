﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal a;
            decimal b;
            decimal c;
            int d;
            Console.WriteLine("Enter the exchange rate from dollars to yuan:");
            c = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Enter 0 to convert from dollars to yuan or 1 for the vice versa");
            d = Convert.ToInt32(Console.ReadLine());
            if (d == 0)
            {
                Console.WriteLine("Enter the dollar ammount:");
                a = Convert.ToDecimal(Console.ReadLine());
                b = a * c;
                Console.WriteLine("{0:c} is {1} yuan",a,b);
            }
            else if(d == 1)
            {
                Console.WriteLine("Enter the yuan ammount:");
                b = Convert.ToDecimal(Console.ReadLine());
                a = b / c;
                Console.WriteLine("{0} yuan is {1:c}", b, a);
            }
            else
            {
                Console.WriteLine("Invalid option ");
                
            }

        }
    }
}
