﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 29 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3._3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b = 5;
            int c = 7;
            Console.WriteLine("Enter an integer:");
            a = Convert.ToInt32(Console.ReadLine());
            if (a % b == 0 ^ a % c == 0)
            {
                Console.WriteLine("{0} is divisible by either 5 or 7",a);
                Console.WriteLine("{0} is divisible by either 5 or 7, but not both", a);
            }
            else if (a % b == 0 || a % c == 0)
            {
                Console.WriteLine("{0} is divisible by 5 and 7 ",a);
                Console.WriteLine("{0} is divisible by either 5 or 7", a);
            }
            else
            {
                Console.WriteLine("{0} is not divisible by 5 or 7",a);

            }
        }
    }
}
