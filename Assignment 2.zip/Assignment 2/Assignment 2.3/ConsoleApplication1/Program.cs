﻿// Rahul Ambarakonda
// CS 5110 TH 1:30 PM
// 23 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            double Weight;
            double Height;
            double BMI;
            Console.WriteLine("Enter Weight in Kilograms: ");
            Weight = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Height in Meters: ");
            Height = Convert.ToDouble(Console.ReadLine());
            BMI = Weight/(Height*Height);
            Console.WriteLine("BMI is {0}", BMI);
        }
    }
}
