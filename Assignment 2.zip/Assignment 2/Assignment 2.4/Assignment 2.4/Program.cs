﻿// Rahul Ambarakonda
// CS 5110 TH 1:30 PM
// 23 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2._4
{
    class Program
    {
        static void Main(string[] args)
        {
            double total;
            double tiprate;
            double tip;
            Console.Write("Enter the subtotal:");
            total = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the tiprate:");
            tiprate = Convert.ToDouble(Console.ReadLine());
            tip = total*(tiprate/100);
            total = total + tip;
            Console.WriteLine("The tip is {0:C} and the total is {1:C}", tip, total);
        }
    }
}
