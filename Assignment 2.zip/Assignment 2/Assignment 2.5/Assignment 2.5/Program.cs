﻿// Rahul Ambarakonda
// CS 5110 TH 1:30 PM
// 23 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2._5
{
    class Program
    {
        static void Main(string[] args)
        {
            double amount;
            double intrestrate;
            double years ;
            Console.Write("Enter investment amount: ");
            amount = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter annual intrest rate as a percentage: ");
            intrestrate = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter number of years ");
            years = Convert.ToDouble(Console.ReadLine());
            amount = amount * Math.Pow((1 + (intrestrate/1200)),years*12);
            Console.WriteLine("Accumilated value is {0:C}", amount);
        }
    }
}
