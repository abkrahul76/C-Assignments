﻿// Rahul Ambarakonda
// CS 5110 TH 1:30 PM
// 23 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            double feet;
            double meters;
            double factor = 0.305;
            Console.Write("Enter a value for feet: ");
            meters = Convert.ToDouble(Console.ReadLine());
            feet = factor * meters;
            Console.WriteLine("{0} feet is {1} meters", meters, feet);
        }
    }
}
