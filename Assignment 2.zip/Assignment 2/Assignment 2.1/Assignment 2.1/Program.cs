﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 23 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\"Hello, World!\"");
        }
    }
}
