package com.example.abkra.codersrestaurant;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class HomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button switchact =(Button)findViewById(R.id.button4);
        switchact.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent act = new Intent(view.getContext(),starters.class);
                startActivity(act);

            }
        });
        Button switchact1 =(Button)findViewById(R.id.button5);
        switchact1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view1) {
                Intent act1 = new Intent(view1.getContext(),soups.class);
                startActivity(act1);

            }
        });
        Button switchact2 =(Button)findViewById(R.id.button6);
        switchact2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view2) {
                Intent act2 = new Intent(view2.getContext(),burgers.class);
                startActivity(act2);

            }
        });
        Button switchact3 =(Button)findViewById(R.id.button8);
        switchact3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view3) {
                Intent act3 = new Intent(view3.getContext(),bevarages.class);
                startActivity(act3);

            }
        });
        Button switchact4 =(Button)findViewById(R.id.button7);
        switchact4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view4) {
                Intent act4 = new Intent(view4.getContext(),chicken.class);
                startActivity(act4);

            }
        });
    }}
