﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 29 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_4._1
{
    class Program
    {
        static void Main(string[] args)
        {
            float a;
            double b;
            Console.WriteLine("Miles \t Kilometers");
            for (a=1; a <= 100;a++)
            {
                b = 1.6090 * a;
                Console.WriteLine("{0} \t {1}", a, b);
                
            }
        }
    }
}
