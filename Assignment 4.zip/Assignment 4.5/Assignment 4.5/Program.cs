﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 29 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_4._5
{
    class Program
    {
        static void Main(string[] args)
        {
            int b;
            int a=0;
            
            double sum=0;
            Console.WriteLine("Itarations\tApproximation");
            for (b = 0; b <= 100000; b++)
            {
                
                if (a % 2 == 0)
                {
                    sum =sum+(4 * (1 / (b + 1.0)));
                }
                if (a % 2 == 1)
                {
                    sum = sum - (4 * (1 / (b + 1.0)));
                }
                if (b % 10000 == 0 && b!=0)
                    Console.WriteLine("{1}\t:{0}", sum, b);
                b++;a++;
               
            }

        }
    }
}