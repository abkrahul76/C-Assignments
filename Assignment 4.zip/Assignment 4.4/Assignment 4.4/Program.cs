﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 29 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_4._4
{
    class Program
    {
        static void Main(string[] args)
        {
            int b;
            double sum=0;
            for (b=1;b<=97;b++)
             {
                 sum =+ (b/(b+2.0));
                 b++;
            }
            Console.WriteLine("sum:{0}", sum);
        }
    }
}
