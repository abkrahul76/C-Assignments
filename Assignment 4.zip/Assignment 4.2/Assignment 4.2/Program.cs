﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 29 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_4._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            double b;
            Console.WriteLine("Kilograms \t Pounds");
            for (a = 1; a <= 99; a++)
            {
                b = 2.2 * a;
                Console.WriteLine("{0} \t {1}", a, b);
            }
        }
    }
}
