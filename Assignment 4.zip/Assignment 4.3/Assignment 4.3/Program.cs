﻿// Rahul Ambarakonda
// CS 5110 TH 01:30 PM
// 29 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_4._3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            double sum = 0;
            double avg = 0;
            int p = 0;
            int n = 0;
            int j;
            for (int i = 0; i >= 0; i++)
            {
                Console.WriteLine("Enter an integer (or 0 to quit):");
                a = Convert.ToInt32(Console.ReadLine());
                if (a > 0)
                    p = p+1;
                if (a < 0)
                    n = n+1;
                if (a == 0)
                {
                    break;
                }
                sum = sum + a;
                j = i + 1;
                avg = sum / j;     
            }
            Console.WriteLine("positives:{0}", p);
            Console.WriteLine("Negatives:{0}", n);
            Console.WriteLine("sum:{0}", sum);
            Console.WriteLine("avg:{0}", avg);
        }
    }
}
